<script>
  import BookList from "$lib/components/books/BookList.svelte";
</script>

<h1>Books</h1>

<BookList />
