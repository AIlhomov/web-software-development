<script>
  import Book from "$lib/components/books/Book.svelte";

  let { data } = $props();
</script>

<Book bookId={data.bookId} />
