<script>
  let { data } = $props();
</script>

<p>book {data.bookId}, chapter {data.chapterId}</p>
