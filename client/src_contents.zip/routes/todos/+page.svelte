<script>
    import TodoList from "$lib/components/todos/TodoList.svelte";
</script>

<TodoList />
