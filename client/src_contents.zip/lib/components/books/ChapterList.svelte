<script>
  let { bookId } = $props();
  let bookChapters = {
    1: [1, 2, 3],
    2: [1, 2, 3, 4],
    3: [1, 2, 3, 4, 5, 6],
  };

  let chapters = bookChapters[bookId] || [];
</script>

<ul>
  {#each chapters as chapter}
    <li>
      <a href={`/books/${bookId}/chapters/${chapter}`}>Chapter {chapter}</a>
    </li>
  {/each}
</ul>
