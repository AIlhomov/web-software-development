<script>
  import ChapterList from "$lib/components/books/ChapterList.svelte";
  let { bookId } = $props();
</script>

<h1>Book {bookId}</h1>

<ChapterList {bookId} />
