<script>
  import Header from "$lib/components/Header.svelte";
  import Footer from "$lib/components/Footer.svelte";
</script>

<Header />

<main>
  <h1>Welcome!</h1>
  <a href="/todos">Go to Todos</a>
</main>

<Footer />
