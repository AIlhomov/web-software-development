<script>
    import { page } from "$app/stores";
    $: todoId = $page.params.todoId;
    $: taskId = $page.params.taskId;
</script>

<main>
    <h1>Todo {todoId}, task {taskId}</h1>
    <a href="/todos/{todoId}">Back to todo</a>
</main>
