export const load = ({ params }) => {
    //console.log("paramaaaas:", params);
    return params;
};
