<script>
    import { page } from "$app/stores";
    $: todoId = $page.params.todoId;
    $: nextTodoId = Number(todoId) + 1;
</script>

<main>
    <h1>Todo {todoId}</h1>
    <a href="/todos/{todoId}/tasks/1">Go to first task</a>
    <br />
    <a href="/todos/{nextTodoId}">Go to next todo</a>
</main>
