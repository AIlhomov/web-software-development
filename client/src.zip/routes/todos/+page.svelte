<script>
    import TodoList from "$lib/components/todos/TodoList.svelte";
    import AddTodo from "$lib/components/todos/AddTodo.svelte";
</script>

<TodoList />
<AddTodo />
