<script>
    // No props needed for todos page
</script>

<main>
    <h1>Todos</h1>
    <a href="/todos/1">Open todo 1</a>
    <br />
    <a href="/todos/1/tasks/1">Open todo 1, task 1</a>
</main>
