<script>
  import BookList from "$lib/components/books/BookList.svelte";
  import AddBook from "$lib/components/books/AddBook.svelte";
</script>

<h1>Books</h1>

<AddBook />

<BookList />
