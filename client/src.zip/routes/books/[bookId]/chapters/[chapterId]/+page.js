export const load = ({ params }) => {
  return params;
};
