<script>
  let { data } = $props();
</script>

<p>book {data.bookId}</p>
{#if data.bookId === 1}
  <p>book id is number 1</p>
{:else}
  <p>book id is not number 1</p>
{/if}
