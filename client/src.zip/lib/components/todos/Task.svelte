<script>
    // Simplify Task component; it should present a single task context if needed.
    let { todoId, taskId } = $props();
</script>

<h1>Todo {todoId}, task {taskId}</h1>
