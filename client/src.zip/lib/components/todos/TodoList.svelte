<script>
    import { useTodoState } from "$lib/states/todoState.svelte.js";
    let todoState = useTodoState();
</script>

<h1>Todos</h1>

<ul>
    {#each todoState.todos as todo (todo.id)}
        <li>{todo.name}</li>
    {/each}
</ul>
