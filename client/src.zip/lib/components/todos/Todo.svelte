<script>
    let { todoId } = $props();
</script>

<h1>Todo {todoId}</h1>

<!-- Task list is rendered at the page level -->
